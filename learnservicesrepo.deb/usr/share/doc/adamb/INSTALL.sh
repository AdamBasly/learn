mkdir -p $DESTDIR/usr/local/bin
cp project $DESTDIR/usr/local/bin
